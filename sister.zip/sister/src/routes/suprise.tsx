import { createFileRoute, Link } from "@tanstack/react-router";

import { useReveal } from "@/hooks/use-reveal";
import decoGift from "@/assets/deco-gift.png";
import shivani3 from "@/assets/shivani-3.jpg.asset.json";

export const Route = createFileRoute("/surprise")({
  head: () => ({
    meta: [
      {
        title: "🎉 Surprise, Shivani! A Secret Page Made Just for You",
      },
      {
        name: "description",
        content:
          "A hidden surprise page made with love, just for Shivani — open only for her.",
      },
      { property: "og:title", content: "🎉 Surprise, Shivani!" },
      {
        property: "og:description",
        content: "A hidden page made with love, just for Shivani.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SurprisePage,
});

const FLOATERS = [
  { left: "6%", size: "text-2xl", delay: "0s", duration: "11s", emoji: "❤️" },
  { left: "18%", size: "text-lg", delay: "3s", duration: "14s", emoji: "💖" },
  { left: "32%", size: "text-xl", delay: "1.5s", duration: "12s", emoji: "🎉" },
  { left: "47%", size: "text-3xl", delay: "5s", duration: "16s", emoji: "❤️" },
  { left: "61%", size: "text-lg", delay: "2.5s", duration: "13s", emoji: "🫶🏻" },
  { left: "74%", size: "text-2xl", delay: "4s", duration: "15s", emoji: "💖" },
  { left: "88%", size: "text-xl", delay: "0.8s", duration: "12s", emoji: "🎉" },
  { left: "94%", size: "text-2xl", delay: "6s", duration: "14s", emoji: "❤️" },
];

function SurprisePage() {
  const reveal = useReveal<HTMLDivElement>(0.05);

  return (
    <main className="relative min-h-screen overflow-x-clip bg-background font-body">
      <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 py-16 text-center">
        <div
          aria-hidden="true"
          className="animate-gradient bg-rainbow absolute inset-0 opacity-95"
        />

        {FLOATERS.map((f) => (
          <span
            key={f.left}
            aria-hidden="true"
            className={`animate-drift pointer-events-none absolute bottom-0 ${f.size} opacity-80`}
            style={{
              left: f.left,
              animationDelay: f.delay,
              animationDuration: f.duration,
            }}
          >
            {f.emoji}
          </span>
        ))}

        <div
          ref={reveal.ref}
          className={`reveal ${reveal.visible ? "reveal-visible" : ""} relative z-10 flex flex-col items-center`}
        >
          <img
            src={decoGift}
            alt="A gift box overflowing with rainbow roses, hearts and butterflies"
            width={1024}
            height={1024}
            className="animate-float-slow w-64 sm:w-80"
          />

          <p className="mt-4 font-script text-5xl text-cream drop-shadow-md sm:text-6xl">
            Surprise, Shivani! 🎉
          </p>
          <p className="mt-6 max-w-xl text-lg text-cream/95 sm:text-xl">
            If you are reading this, you found the secret page — which means
            someone loves you more than words can ever say.
          </p>

          <div className="mt-10 -rotate-2 rounded-4xl border-8 border-white bg-white p-2 shadow-2xl shadow-rose-deep/40">
            <img
              src={shivani3.url}
              alt="Shivani smiling"
              className="h-64 w-56 rounded-3xl object-cover sm:h-80 sm:w-64"
            />
            <p className="py-2 font-script text-2xl text-magenta">
              always this beautiful 💕
            </p>
          </div>

          <p className="mt-10 max-w-xl font-display text-2xl leading-relaxed text-white drop-shadow sm:text-3xl">
            Thank you for being my sister, my friend, and my home.
            <br />
            I love you forever. ❤️
          </p>

          <Link
            to="/"
            className="mt-10 rounded-full bg-white/90 px-6 py-3 font-medium text-rose-deep shadow-lg transition-transform hover:scale-105"
          >
            ← Back to our story
          </Link>
        </div>
      </section>
    </main>
  );
}
