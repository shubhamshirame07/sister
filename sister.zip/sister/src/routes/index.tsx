import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";

import { useReveal } from "@/hooks/use-reveal";
import shivani1 from "@/assets/shivani-1.jpg.asset.json";
import shivani2 from "@/assets/shivani-2.jpg.asset.json";
import shivani3 from "@/assets/shivani-3.jpg.asset.json";
import shivani4 from "@/assets/shivani-4.jpg.asset.json";
import decoGarland from "@/assets/deco-garland.png";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "Sister Shivani ❤️ A Little World Made Just for You",
      },
      {
        name: "description",
        content:
          "A colorful surprise tribute for my sister Shivani — our photos, our memories, our bond, and the 20th of August we never forget.",
      },
      { property: "og:title", content: "Sister Shivani ❤️ A Gift From Your Brother" },
      {
        property: "og:description",
        content:
          "Our photos, our memories, our bond — a surprise page made with love for Shivani.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const PHOTOS = [
  { src: shivani1, caption: "Beautiful inside and out" },
  { src: shivani2, caption: "Grace in every step" },
  { src: shivani3, caption: "Traditional, timeless charm" },
  { src: shivani4, caption: "That smile of yours ✨" },
];

const STANZAS = [
  {
    lines: [
      "My sister is a piece of my heart,",
      "A bond that words can never fully explain.",
      "She knows the real me better than anyone.",
      "She understands my silence and my feelings.",
    ],
    bg: "bg-blush",
  },
  {
    lines: [
      "When I feel lost, she helps me find my way.",
      "When I feel weak, she reminds me to be strong.",
      "Her love is quiet, but it is always there.",
      "Her care is something I can never replace.",
    ],
    bg: "bg-secondary",
  },
  {
    lines: [
      "We have shared countless memories together.",
      "Some made us laugh, some made us cry.",
      "Even our little fights became beautiful memories.",
      "Growing up with you, Shivani, is one of my blessings.",
    ],
    bg: "bg-blush",
  },
  {
    lines: [
      "You have seen my failures and still believed in me.",
      "You have seen my tears and never judged me.",
      "You celebrate my happiness as if it were your own.",
      "Your happiness brings a smile to my heart.",
    ],
    bg: "bg-secondary",
  },
  {
    lines: [
      "No matter how much life changes,",
      "Our childhood bond will always remain special.",
      "Distance may keep us apart sometimes,",
      "But it can never separate our hearts.",
    ],
    bg: "bg-blush",
  },
  {
    lines: [
      "Shivani, you are my sister, my friend, and my forever support.",
      "Whenever life gets difficult, I know you are there.",
      "Our memories will stay with me forever.",
      "Our bond will grow stronger with every passing year.",
    ],
    bg: "bg-secondary",
  },
  {
    lines: [
      "I will always protect and support your dreams.",
      "I will always be proud to call you my sister.",
      "You are one of the most precious people in my life.",
      "And I will love and cherish our bond forever. ❤️🫂",
    ],
    bg: "bg-blush",
  },
];

const PASTELS = [
  "bg-blush",
  "bg-lilac",
  "bg-peach",
  "bg-mint",
  "bg-sky",
  "bg-lemon",
];

// Deterministic floating hearts (fixed positions, no randomness -> SSR-safe)
const FLOATERS = [
  { left: "6%", size: "text-2xl", delay: "0s", duration: "11s", emoji: "❤️" },
  { left: "18%", size: "text-lg", delay: "3s", duration: "14s", emoji: "💖" },
  { left: "32%", size: "text-xl", delay: "1.5s", duration: "12s", emoji: "🎀" },
  { left: "47%", size: "text-3xl", delay: "5s", duration: "16s", emoji: "❤️" },
  { left: "61%", size: "text-lg", delay: "2.5s", duration: "13s", emoji: "🫶🏻" },
  { left: "74%", size: "text-2xl", delay: "4s", duration: "15s", emoji: "💖" },
  { left: "88%", size: "text-xl", delay: "0.8s", duration: "12s", emoji: "🎀" },
  { left: "94%", size: "text-2xl", delay: "6s", duration: "14s", emoji: "❤️" },
];

const SPARKLES = [
  { top: "18%", left: "12%", delay: "0s" },
  { top: "30%", left: "82%", delay: "1s" },
  { top: "64%", left: "22%", delay: "2s" },
  { top: "12%", left: "55%", delay: "0.5s" },
  { top: "78%", left: "68%", delay: "1.6s" },
  { top: "45%", left: "8%", delay: "2.4s" },
];

function Stanza({
  lines,
  bg,
  index,
}: {
  lines: string[];
  bg: string;
  index: number;
}) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "reveal-visible" : ""} ${bg} rounded-4xl border border-rose/15 p-8 shadow-lg shadow-rose/10 sm:p-10`}
      style={{ transitionDelay: `${(index % 2) * 80}ms` }}
    >
      <div className="mb-4 text-3xl" aria-hidden="true">
        {index % 2 === 0 ? "❤️" : "🌸"}
      </div>
      <p className="space-y-2 text-lg leading-relaxed text-ink sm:text-xl">
        {lines.map((line) => (
          <span key={line} className="block">
            {line}
          </span>
        ))}
      </p>
    </div>
  );
}

function Index() {
  const [slide, setSlide] = useState(0);
  const [query, setQuery] = useState("");
  const [hint, setHint] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const timer = setInterval(() => {
      setSlide((s) => (s + 1) % PHOTOS.length);
    }, 4200);
    return () => clearInterval(timer);
  }, []);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (query.trim().toLowerCase() === "shivani") {
      router.navigate({ to: "/surprise" });
    } else {
      setHint(true);
    }
  };

  const heroReveal = useReveal<HTMLDivElement>(0.05);

  return (
    <main className="relative min-h-screen overflow-x-clip bg-background font-body">
      {/* ============ HERO ============ */}
      <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 py-16 text-center">
        {/* animated colorful gradient */}
        <div
          aria-hidden="true"
          className="animate-gradient bg-rainbow absolute inset-0 opacity-95"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent"
        />

        {/* drifting hearts */}
        {FLOATERS.map((f) => (
          <span
            key={f.left}
            aria-hidden="true"
            className={`animate-drift pointer-events-none absolute bottom-0 ${f.size} opacity-80`}
            style={{
              left: f.left,
              animationDelay: f.delay,
              animationDuration: f.duration,
            }}
          >
            {f.emoji}
          </span>
        ))}

        {/* twinkling sparkles */}
        {SPARKLES.map((s, i) => (
          <span
            key={i}
            aria-hidden="true"
            className="animate-twinkle pointer-events-none absolute text-xl text-white"
            style={{ top: s.top, left: s.left, animationDelay: s.delay }}
          >
            ✦
          </span>
        ))}

        <div ref={heroReveal.ref} className={`reveal ${heroReveal.visible ? "reveal-visible" : ""} relative z-10`}>
          <p className="font-script text-4xl text-cream drop-shadow-md sm:text-5xl">
            For the world's best sister
          </p>
          <h1 className="mt-4 font-display text-5xl leading-tight text-white drop-shadow-lg sm:text-7xl">
            Sister Shivani...!!!!
          </h1>
          <p className="animate-heartbeat mt-3 text-3xl sm:text-4xl" aria-hidden="true">
            ❤️🥹🎀🫶🏻
          </p>
          <p className="mx-auto mt-6 max-w-xl text-lg text-cream/95 sm:text-xl">
            A little corner of the internet, made only for you — with all my
            love, all our memories, and one date I will never forget.
          </p>
        </div>

        {/* hero photo in a tilted frame */}
        <div className="animate-float-slow relative z-10 mt-10">
          <div className="rotate-2 rounded-4xl border-8 border-white bg-white p-2 shadow-2xl shadow-rose-deep/40">
            <img
              src={shivani1.url}
              alt="Shivani smiling in a beautiful saree"
              className="h-72 w-64 rounded-3xl object-cover sm:h-96 sm:w-80"
            />
            <p className="py-2 font-script text-2xl text-magenta">Shivani 💕</p>
          </div>
        </div>

        <a
          href="#moments"
          className="relative z-10 mt-12 rounded-full bg-white/90 px-6 py-3 font-medium text-rose-deep shadow-lg transition-transform hover:scale-105"
        >
          Scroll for your surprise ↓
        </a>
      </section>

      {/* ============ PHOTO SLIDER ============ */}
      <section id="moments" className="relative bg-cream py-20">
        <div className="mx-auto max-w-4xl px-4">
          <img
            src={decoGarland}
            alt=""
            width={1536}
            height={512}
            loading="lazy"
            className="mx-auto -mb-4 w-full max-w-2xl drop-shadow-xl"
          />
          <h2 className="text-center font-display text-4xl text-rose-deep sm:text-5xl">
            Our Moments
          </h2>
          <p className="mt-3 text-center font-script text-3xl text-magenta">
            every picture of you is my favourite
          </p>

          <div className="group relative mt-10 overflow-hidden rounded-4xl border-4 border-white bg-white shadow-2xl shadow-rose/30">
            <div
              className="flex transition-transform duration-700 ease-out"
              style={{ transform: `translateX(-${slide * 100}%)` }}
            >
              {PHOTOS.map((photo, i) => (
                <div key={i} className="relative w-full shrink-0">
                  <img
                    src={photo.src.url}
                    alt={photo.caption}
                    className="h-[380px] w-full object-cover sm:h-[470px]"
                  />
                  <p className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent p-6 text-center text-xl text-white">
                    {photo.caption}
                  </p>
                </div>
              ))}
            </div>

            <button
              type="button"
              aria-label="Previous photo"
              onClick={() =>
                setSlide((s) => (s - 1 + PHOTOS.length) % PHOTOS.length)
              }
              className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/85 px-3 py-2 text-xl text-rose-deep shadow transition hover:scale-110"
            >
              ‹
            </button>
            <button
              type="button"
              aria-label="Next photo"
              onClick={() => setSlide((s) => (s + 1) % PHOTOS.length)}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/85 px-3 py-2 text-xl text-rose-deep shadow transition hover:scale-110"
            >
              ›
            </button>
          </div>

          <div className="mt-6 flex justify-center gap-3">
            {PHOTOS.map((_, i) => (
              <button
                key={i}
                type="button"
                aria-label={`Go to photo ${i + 1}`}
                onClick={() => setSlide(i)}
                className={`h-3 rounded-full transition-all ${
                  i === slide ? "w-8 bg-rose" : "w-3 bg-rose/30"
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ============ 20 AUGUST ============ */}
      <section className="relative overflow-hidden bg-gradient-to-b from-cream to-blush py-24">
        <div
          aria-hidden="true"
          className="animate-twinkle absolute left-[10%] top-16 text-2xl text-gold"
        >
          ✦
        </div>
        <div
          aria-hidden="true"
          className="animate-twinkle absolute right-[12%] top-24 text-2xl text-gold"
          style={{ animationDelay: "1.2s" }}
        >
          ✦
        </div>
        <div
          aria-hidden="true"
          className="animate-twinkle absolute bottom-16 left-[22%] text-xl text-gold"
          style={{ animationDelay: "2s" }}
        >
          ✦
        </div>

        <div className="mx-auto max-w-3xl px-4 text-center">
          <p className="font-script text-4xl text-magenta sm:text-5xl">
            Marked on my heart forever
          </p>
          <div className="animate-float-slower mx-auto mt-8 w-fit rounded-4xl bg-white p-10 shadow-2xl shadow-rose/25">
            <span
              aria-hidden="true"
              className="animate-heartbeat block text-4xl"
            >
              🫶🏻
            </span>
            <p className="mt-2 font-display text-6xl leading-none text-rose sm:text-8xl">
              20 August
            </p>
            <p className="mt-3 text-lg text-muted-foreground">
              the day we met — my favourite date of the year
            </p>
          </div>
          <p className="mx-auto mt-10 max-w-xl text-lg leading-relaxed text-ink sm:text-xl">
            Some days just stay. That day we met is one of them — it quietly
            became one of the best things that ever happened to me.
          </p>
        </div>
      </section>

      {/* ============ SECRET SEARCH ============ */}
      <section className="bg-gradient-to-b from-cream to-mint py-24">
        <div className="mx-auto max-w-xl px-4 text-center">
          <p className="font-script text-4xl text-violet sm:text-5xl">
            something is hidden here
          </p>
          <h2 className="mt-2 font-display text-4xl text-rose-deep sm:text-5xl">
            Search for Your Surprise
          </h2>
          <form
            onSubmit={handleSearch}
            className="mt-8 flex flex-col items-center gap-4 sm:flex-row"
          >
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setHint(false);
              }}
              placeholder="Type a name..."
              aria-label="Search for your surprise"
              className="w-full rounded-full border border-rose/30 bg-white px-6 py-3 text-center text-lg text-ink shadow-inner outline-none placeholder:text-muted-foreground focus:border-rose"
            />
            <button
              type="submit"
              className="w-full shrink-0 rounded-full bg-violet px-8 py-3 text-lg font-medium text-cream shadow-lg transition-transform hover:scale-105 sm:w-auto"
            >
              Search ✨
            </button>
          </form>
          {hint ? (
            <p className="mt-4 text-lg text-rose-deep">
              Not that one... try typing &quot;Shivani&quot; 😉
            </p>
          ) : null}
        </div>
      </section>

      {/* ============ POEM ============ */}
      <section className="bg-gradient-to-b from-mint to-blush py-24">
        <div className="mx-auto max-w-2xl px-4">
          <h2 className="text-center font-display text-4xl text-violet sm:text-5xl">
            A Letter From My Heart
          </h2>
          <p className="mt-3 text-center font-script text-3xl text-magenta">
            words I never said out loud
          </p>

          <div className="mt-12 space-y-8">
            {STANZAS.map((stanza, i) => (
              <Stanza
                key={i}
                lines={stanza.lines}
                bg={PASTELS[i % PASTELS.length] ?? "bg-blush"}
                index={i}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="animate-gradient bg-rainbow relative overflow-hidden py-16 text-center">
        {FLOATERS.slice(0, 4).map((f) => (
          <span
            key={f.left}
            aria-hidden="true"
            className="animate-drift pointer-events-none absolute bottom-0 text-xl opacity-70"
            style={{
              left: f.left,
              animationDelay: f.delay,
              animationDuration: f.duration,
            }}
          >
            💖
          </span>
        ))}
        <p className="animate-shimmer relative bg-[linear-gradient(90deg,#fff8f0,#ffd7e6,#fff8f0)] bg-clip-text font-display text-4xl text-transparent sm:text-5xl">
          Love you, Shivani ❤️
        </p>
        <p className="relative mt-4 font-script text-3xl text-cream">
          made with all my heart, by your brother
        </p>
      </footer>
    </main>
  );
}
